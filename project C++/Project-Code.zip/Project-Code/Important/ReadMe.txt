For Manager:
	1-username and passeord:
		a-Zian(123456).
		b-Sami(654321)
		c-Leepu(456789)
                d-Istiak(234567)